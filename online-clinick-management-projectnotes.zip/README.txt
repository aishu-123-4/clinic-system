Thanks for downloading this online clinck management system. 

To run this project make a database named as "ocms" in your database.

Then open your project saving in localhost.

Enjoy!!

https://projectnotes.org/